// main.cpp
//
// ICS 46 Spring 2018
// Project #1: Dark at the End of the Tunnel
//
// This is the program's main() function, which launches the GUI.  You will
// not want to make any changes to this file.

#include "DarkApplication.hpp"


int main(int argc, char** argv)
{
    DarkApplication{}.run(argc, argv);
    return 0;
}

